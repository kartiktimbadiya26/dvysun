<?php
include_once "database/db.php";

if (!isset($_GET["id"])) {
      header("location:blog.php");
}

$id = $_GET["id"];

$query = "SELECT * FROM blog WHERE id=$id";
$result = mysqli_query($conn, $query);
$row = $result->fetch_assoc();

include_once "header.php";

?>


<main id="content" class="wrapper layout-page">
      <section class="z-index-2 position-relative pb-2 mb-12">
            <div class="bg-body-secondary mb-3">
                  <div class="container">
                        <nav class="py-4 lh-30px" aria-label="breadcrumb">
                              <ol class="breadcrumb justify-content-center py-1 mb-0">
                                    <li class="breadcrumb-item"><a title="Home" href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Blog Update</li>
                              </ol>
                        </nav>
                  </div>
            </div>
      </section>
      <section class="pt-10 pb-16 pb-lg-18 container"  style="overflow-x: hidden;" >
            <div class="px-lg-25 px-0">
                  <div class=" text-center mb-13">
                        <h2 class=" px-6 text-body-emphasis border-0 fw-500 mb-4 fs-3 ">
                              Are You Washing Your Face Properly?
                        </h2>
                        <ul class="list-inline fs-15px fw-semibold letter-spacing-01 d-flex justify-content-center align-items-center">
                              <li><img data-src="../assets/images/blog/post-detail-header-img.png" alt="Grace" class="lazy-image img-fluid" src="#"></li>
                              <li class="border-end px-6 text-body-emphasis border-0 text-body">
                                    By
                                    <a href="#">Admin</a>
                              </li>
                              <li class="list-inline-item px-6">
                                    <?php $date = new DateTime($row["createdate"]);
                                    echo $date->format('M jS, Y'); ?>
                              </li>
                        </ul>
                  </div>
            </div>
            <div style="overflow-x: scroll;">
                  <?php echo $row["description"]; ?>
            </div>
            <div class="border-bottom"></div>
      </section>
</main>

<?php include_once "footer.php"; ?>