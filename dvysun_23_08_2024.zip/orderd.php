<?php

include_once "database/db.php";


if (!$user) {
      header("location:login.php");
}
include_once "header.php";

?>


<main>
      <section class="z-index-2 position-relative pb-2 mb-12">
            <div class="bg-body-secondary mb-3">
                  <div class="container">
                        <nav class="py-4 lh-30px" aria-label="breadcrumb">
                              <ol class="breadcrumb justify-content-center py-1 mb-0">
                                    <li class="breadcrumb-item"><a title="Home" href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Successfully</li>
                              </ol>
                        </nav>
                  </div>
            </div>
      </section>
      <section class="z-index-2 position-relative p-25 mb-12 text-center ">
            <h1 class="" style="color: greenyellow; font-size: 150px;">
                  <i class="fa-solid fa-check"></i>
            </h1>
            <h1 class="display-1" style="color: greenyellow;">
                  Order Placed Successfully
            </h1>
      </section>
</main>


<?php include_once "footer.php"; ?>