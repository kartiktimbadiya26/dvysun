<?php
include_once "../database/db.php";
include_once "chek_login.php";

if (!isset($_SESSION["admin"])) {
      header("location: index.php");
}
include_once "header.php";
?>



<?php include_once "footer.php"; ?>