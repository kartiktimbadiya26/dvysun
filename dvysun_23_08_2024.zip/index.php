<?php include_once "header.php"; ?>

<main id="content" class="wrapper layout-page">
      <section>
            <div class="slick-slider hero hero-header-01"
                  data-slick-options="{&#34;arrows&#34;:false,&#34;autoplay&#34;:true,&#34;cssEase&#34;:&#34;ease-in-out&#34;,&#34;dots&#34;:false,&#34;fade&#34;:true,&#34;infinite&#34;:true,&#34;slidesToShow&#34;:1,&#34;speed&#34;:600}">
                  <div class="vh-100 d-flex align-items-center">
                        <div class="z-index-2 container container-xxl py-21 pt-xl-10 pb-xl-11">
                              <div class="hero-content text-start">
                                    <div data-animate="fadeInDown">
                                          <p class="text-body-emphasis mb-8 text-uppercase fw-semibold fs-15px">
                                                Essenstial Items</p>
                                          <h1 class="mb-7 hero-title">Beauty Inspired <br> by Real Life</h1>
                                          <p class="hero-desc text-body-calculate fs-18px mb-11">Made using clean,
                                                non-toxic ingredients, our products are designed for everyone.</p>
                                    </div>
                                    <a href="grid-layout.php" data-animate="fadeInUp"
                                          class="btn btn-lg btn-dark btn-hover-bg-primary btn-hover-border-primary">
                                          Shop Now
                                    </a>
                              </div>
                        </div>
                        <div class="lazy-bg bg-overlay position-absolute z-index-1 w-100 h-100   light-mode-img"
                              data-bg-src="assets/images/hero-slider/hero-slider-01.jpg">
                        </div>
                        <div class="lazy-bg bg-overlay dark-mode-img position-absolute z-index-1 w-100 h-100"
                              data-bg-src="assets/images/hero-slider/hero-slider-white-01.jpg">
                        </div>
                  </div>
                  <div class="vh-100 d-flex align-items-center">
                        <div class="z-index-2 container container-xxl py-21 pt-xl-10 pb-xl-11">
                              <div class="hero-content text-start">
                                    <div data-animate="fadeInDown">
                                          <p class="text-body-emphasis mb-8 text-uppercase fw-semibold fs-15px">
                                                New collection</p>
                                          <h1 class="mb-7 hero-title">Get The Perfectly <br> Hydrated Skin</h1>
                                          <p class="hero-desc text-body-calculate fs-18px mb-11">Made using clean,
                                                non-toxic ingredients, our products are designed for everyone.</p>
                                    </div>
                                    <a href="grid-layout.php" data-animate="fadeInUp"
                                          class="btn btn-lg btn-dark btn-hover-bg-primary btn-hover-border-primary">
                                          Shop Now
                                    </a>
                              </div>
                        </div>
                        <div class="lazy-bg bg-overlay position-absolute z-index-1 w-100 h-100   light-mode-img"
                              data-bg-src="assets/images/hero-slider/hero-slider-02.jpg">
                        </div>
                        <div class="lazy-bg bg-overlay dark-mode-img position-absolute z-index-1 w-100 h-100"
                              data-bg-src="assets/images/hero-slider/hero-slider-white-02.jpg">
                        </div>
                  </div>
                  <div class="vh-100 d-flex align-items-center">
                        <div class="z-index-2 container container-xxl py-21 pt-xl-10 pb-xl-11">
                              <div class="hero-content text-start">
                                    <div data-animate="fadeInDown">
                                          <p class="text-body-emphasis mb-8 text-uppercase fw-semibold fs-15px">
                                                Get the glow</p>
                                          <h1 class="mb-7 hero-title">Be Your <br> Kind of Beauty</h1>
                                          <p class="hero-desc text-body-calculate fs-18px mb-11">Made using clean,
                                                non-toxic ingredients, our products are designed for everyone.</p>
                                    </div>
                                    <a href="grid-layout.php" data-animate="fadeInUp"
                                          class="btn btn-lg btn-dark btn-hover-bg-primary btn-hover-border-primary">
                                          Shop Now
                                    </a>
                              </div>
                        </div>
                        <div class="lazy-bg bg-overlay position-absolute z-index-1 w-100 h-100   light-mode-img"
                              data-bg-src="assets/images/hero-slider/hero-slider-03.jpg">
                        </div>
                        <div class="lazy-bg bg-overlay dark-mode-img position-absolute z-index-1 w-100 h-100"
                              data-bg-src="assets/images/hero-slider/hero-slider-white-03.jpg">
                        </div>
                  </div>
            </div>
      </section>
      <section>
            <div class="container container-xxl py-lg-17 pt-14 pb-16">
                  <div class="mb-13 pb-3 text-center" data-animate="fadeInUp">
                        <h2 class="mb-5">Our Featured Products</h2>
                        <p class="fs-18px mb-0">Get the skin you want to feel</p>
                  </div>
                  <div class="slick-slider"
                        data-slick-options="{&#34;arrows&#34;:true,&#34;dots&#34;:false,&#34;responsive&#34;:[{&#34;breakpoint&#34;:1560,&#34;settings&#34;:{&#34;arrows&#34;:false,&#34;dots&#34;:true}},{&#34;breakpoint&#34;:1200,&#34;settings&#34;:{&#34;arrows&#34;:false,&#34;dots&#34;:true,&#34;slidesToShow&#34;:3}},{&#34;breakpoint&#34;:992,&#34;settings&#34;:{&#34;arrows&#34;:false,&#34;dots&#34;:true,&#34;slidesToShow&#34;:2}},{&#34;breakpoint&#34;:576,&#34;settings&#34;:{&#34;arrows&#34;:false,&#34;dots&#34;:true,&#34;slidesToShow&#34;:1}}],&#34;slidesToShow&#34;:4}">
                        <div>
                              <div class="card card-product grid-1 bg-transparent border-0" data-animate="fadeInUp">
                                    <figure class="card-img-top position-relative mb-7 overflow-hidden ">
                                          <a href="shop/product-details-v1.html" class="hover-zoom-in d-block"
                                                title="Shield Conditioner">
                                                <img src="#" data-src="./assets/images/products/product-01-330x440.jpg"
                                                      class="img-fluid lazy-image w-100" alt="Shield Conditioner"
                                                      width="330" height="440">
                                          </a>
                                          <div class="position-absolute product-flash z-index-2 "><span
                                                      class="badge badge-product-flash on-sale bg-primary">-25%</span>
                                          </div>
                                          <div class="position-absolute d-flex z-index-2 product-actions  horizontal">
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm add_to_cart"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Add To Cart">
                                                      <svg class="icon icon-shopping-bag-open-light">
                                                            <use xlink:href="#icon-shopping-bag-open-light"></use>
                                                      </svg>
                                                </a><a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm quick-view"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Quick View">
                                                      <span data-bs-toggle="modal" data-bs-target="#quickViewModal"
                                                            class="d-flex align-items-center justify-content-center">
                                                            <svg class="icon icon-eye-light">
                                                                  <use xlink:href="#icon-eye-light"></use>
                                                            </svg>
                                                      </span>
                                                </a>
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm wishlist"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Add To Wishlist">
                                                      <svg class="icon icon-star-light">
                                                            <use xlink:href="#icon-star-light"></use>
                                                      </svg>
                                                </a>
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm compare"
                                                      href="shop/compare.html" data-bs-toggle="tooltip"
                                                      data-bs-placement="top" data-bs-title="Compare">
                                                      <svg class="icon icon-arrows-left-right-light">
                                                            <use xlink:href="#icon-arrows-left-right-light"></use>
                                                      </svg>
                                                </a>
                                          </div>
                                    </figure>
                                    <div class="card-body text-center p-0">
                                          <span
                                                class="d-flex align-items-center price text-body-emphasis fw-bold justify-content-center mb-3 fs-6">
                                                <del class=" text-body fw-500 me-4 fs-13px">₹40.00</del>
                                                <ins class="text-decoration-none">₹30.00</ins></span>
                                          <h4
                                                class="product-title card-title text-primary-hover text-body-emphasis fs-15px fw-500 mb-3">
                                                <a class="text-decoration-none text-reset"
                                                      href="shop/product-details-v1.html">Shield Conditioner</a>
                                          </h4>
                                          <div class="d-flex align-items-center fs-12px justify-content-center">
                                                <div class="rating">
                                                      <div class="empty-stars">
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                      </div>
                                                      <div class="filled-stars" style="width: 80%">
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                      </div>
                                                </div><span class="reviews ms-4 pt-3 fs-14px">2947 reviews</span>
                                          </div>
                                    </div>
                              </div>
                        </div>
                        <div>
                              <div class="card card-product grid-1 bg-transparent border-0" data-animate="fadeInUp">
                                    <figure class="card-img-top position-relative mb-7 overflow-hidden ">
                                          <a href="shop/product-details-v1.html" class="hover-zoom-in d-block"
                                                title="Perfecting Facial Oil">
                                                <img src="#" data-src="./assets/images/products/product-02-330x440.jpg"
                                                      class="img-fluid lazy-image w-100" alt="Perfecting Facial Oil"
                                                      width="330" height="440">
                                          </a>
                                          <div class="position-absolute d-flex z-index-2 product-actions  horizontal">
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm add_to_cart"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Add To Cart">
                                                      <svg class="icon icon-shopping-bag-open-light">
                                                            <use xlink:href="#icon-shopping-bag-open-light"></use>
                                                      </svg>
                                                </a><a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm quick-view"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Quick View">
                                                      <span data-bs-toggle="modal" data-bs-target="#quickViewModal"
                                                            class="d-flex align-items-center justify-content-center">
                                                            <svg class="icon icon-eye-light">
                                                                  <use xlink:href="#icon-eye-light"></use>
                                                            </svg>
                                                      </span>
                                                </a>
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm wishlist"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Add To Wishlist">
                                                      <svg class="icon icon-star-light">
                                                            <use xlink:href="#icon-star-light"></use>
                                                      </svg>
                                                </a>
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm compare"
                                                      href="shop/compare.html" data-bs-toggle="tooltip"
                                                      data-bs-placement="top" data-bs-title="Compare">
                                                      <svg class="icon icon-arrows-left-right-light">
                                                            <use xlink:href="#icon-arrows-left-right-light"></use>
                                                      </svg>
                                                </a>
                                          </div>
                                    </figure>
                                    <div class="card-body text-center p-0">
                                          <span
                                                class="d-flex align-items-center price text-body-emphasis fw-bold justify-content-center mb-3 fs-6">₹20.00</span>
                                          <h4
                                                class="product-title card-title text-primary-hover text-body-emphasis fs-15px fw-500 mb-3">
                                                <a class="text-decoration-none text-reset"
                                                      href="shop/product-details-v1.html">Perfecting Facial
                                                      Oil</a>
                                          </h4>
                                          <div class="d-flex align-items-center fs-12px justify-content-center">
                                                <div class="rating">
                                                      <div class="empty-stars">
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                      </div>
                                                      <div class="filled-stars" style="width: 100%">
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                      </div>
                                                </div><span class="reviews ms-4 pt-3 fs-14px">2947 reviews</span>
                                          </div>
                                    </div>
                              </div>
                        </div>
                        <div>
                              <div class="card card-product grid-1 bg-transparent border-0" data-animate="fadeInUp">
                                    <figure class="card-img-top position-relative mb-7 overflow-hidden ">
                                          <a href="shop/product-details-v1.html" class="hover-zoom-in d-block"
                                                title="Enriched Hand &amp; Body Wash">
                                                <img src="#" data-src="./assets/images/products/product-03-330x440.jpg"
                                                      class="img-fluid lazy-image w-100"
                                                      alt="Enriched Hand &amp; Body Wash" width="330" height="440">
                                          </a>
                                          <div class="position-absolute product-flash z-index-2 "><span
                                                      class="badge badge-product-flash on-new">New</span></div>
                                          <div class="position-absolute d-flex z-index-2 product-actions  horizontal">
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm add_to_cart"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Add To Cart">
                                                      <svg class="icon icon-shopping-bag-open-light">
                                                            <use xlink:href="#icon-shopping-bag-open-light"></use>
                                                      </svg>
                                                </a><a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm quick-view"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Quick View">
                                                      <span data-bs-toggle="modal" data-bs-target="#quickViewModal"
                                                            class="d-flex align-items-center justify-content-center">
                                                            <svg class="icon icon-eye-light">
                                                                  <use xlink:href="#icon-eye-light"></use>
                                                            </svg>
                                                      </span>
                                                </a>
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm wishlist"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Add To Wishlist">
                                                      <svg class="icon icon-star-light">
                                                            <use xlink:href="#icon-star-light"></use>
                                                      </svg>
                                                </a>
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm compare"
                                                      href="shop/compare.html" data-bs-toggle="tooltip"
                                                      data-bs-placement="top" data-bs-title="Compare">
                                                      <svg class="icon icon-arrows-left-right-light">
                                                            <use xlink:href="#icon-arrows-left-right-light"></use>
                                                      </svg>
                                                </a>
                                          </div>
                                    </figure>
                                    <div class="card-body text-center p-0">
                                          <span
                                                class="d-flex align-items-center price text-body-emphasis fw-bold justify-content-center mb-3 fs-6">₹29.00</span>
                                          <h4
                                                class="product-title card-title text-primary-hover text-body-emphasis fs-15px fw-500 mb-3">
                                                <a class="text-decoration-none text-reset"
                                                      href="shop/product-details-v1.html">Enriched Hand &amp; Body
                                                      Wash</a>
                                          </h4>
                                          <div class="d-flex align-items-center fs-12px justify-content-center">
                                                <div class="rating">
                                                      <div class="empty-stars">
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                      </div>
                                                      <div class="filled-stars" style="width: 100%">
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                      </div>
                                                </div><span class="reviews ms-4 pt-3 fs-14px">2947 reviews</span>
                                          </div>
                                    </div>
                              </div>
                        </div>
                        <div>
                              <div class="card card-product grid-1 bg-transparent border-0" data-animate="fadeInUp">
                                    <figure class="card-img-top position-relative mb-7 overflow-hidden ">
                                          <a href="shop/product-details-v1.html" class="hover-zoom-in d-block"
                                                title="Shield Shampoo">
                                                <img src="#" data-src="./assets/images/products/product-04-330x440.jpg"
                                                      class="img-fluid lazy-image w-100" alt="Shield Shampoo"
                                                      width="330" height="440">
                                          </a>
                                          <div class="position-absolute product-flash z-index-2 "><span
                                                      class="badge badge-product-flash on-sale bg-primary">-24%</span>
                                          </div>
                                          <div class="position-absolute d-flex z-index-2 product-actions  horizontal">
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm add_to_cart"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Add To Cart">
                                                      <svg class="icon icon-shopping-bag-open-light">
                                                            <use xlink:href="#icon-shopping-bag-open-light"></use>
                                                      </svg>
                                                </a><a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm quick-view"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Quick View">
                                                      <span data-bs-toggle="modal" data-bs-target="#quickViewModal"
                                                            class="d-flex align-items-center justify-content-center">
                                                            <svg class="icon icon-eye-light">
                                                                  <use xlink:href="#icon-eye-light"></use>
                                                            </svg>
                                                      </span>
                                                </a>
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm wishlist"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Add To Wishlist">
                                                      <svg class="icon icon-star-light">
                                                            <use xlink:href="#icon-star-light"></use>
                                                      </svg>
                                                </a>
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm compare"
                                                      href="shop/compare.html" data-bs-toggle="tooltip"
                                                      data-bs-placement="top" data-bs-title="Compare">
                                                      <svg class="icon icon-arrows-left-right-light">
                                                            <use xlink:href="#icon-arrows-left-right-light"></use>
                                                      </svg>
                                                </a>
                                          </div>
                                    </figure>
                                    <div class="card-body text-center p-0">
                                          <span
                                                class="d-flex align-items-center price text-body-emphasis fw-bold justify-content-center mb-3 fs-6">
                                                <del class=" text-body fw-500 me-4 fs-13px">₹25.00</del>
                                                <ins class="text-decoration-none">₹19.00</ins></span>
                                          <h4
                                                class="product-title card-title text-primary-hover text-body-emphasis fs-15px fw-500 mb-3">
                                                <a class="text-decoration-none text-reset"
                                                      href="shop/product-details-v1.html">Shield Shampoo</a>
                                          </h4>
                                          <div class="d-flex align-items-center fs-12px justify-content-center">
                                                <div class="rating">
                                                      <div class="empty-stars">
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                      </div>
                                                      <div class="filled-stars" style="width: 80%">
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                      </div>
                                                </div><span class="reviews ms-4 pt-3 fs-14px">2947 reviews</span>
                                          </div>
                                    </div>
                              </div>
                        </div>
                        <div>
                              <div class="card card-product grid-1 bg-transparent border-0" data-animate="fadeInUp">
                                    <figure class="card-img-top position-relative mb-7 overflow-hidden ">
                                          <a href="shop/product-details-v1.html" class="hover-zoom-in d-block"
                                                title="Enriched Hand Wash">
                                                <img src="#" data-src="./assets/images/products/product-05-330x440.jpg"
                                                      class="img-fluid lazy-image w-100" alt="Enriched Hand Wash"
                                                      width="330" height="440">
                                          </a>
                                          <div class="position-absolute product-flash z-index-2 "><span
                                                      class="badge badge-product-flash on-sale bg-primary">-26%</span>
                                          </div>
                                          <div class="position-absolute d-flex z-index-2 product-actions  horizontal">
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm add_to_cart"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Add To Cart">
                                                      <svg class="icon icon-shopping-bag-open-light">
                                                            <use xlink:href="#icon-shopping-bag-open-light"></use>
                                                      </svg>
                                                </a><a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm quick-view"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Quick View">
                                                      <span data-bs-toggle="modal" data-bs-target="#quickViewModal"
                                                            class="d-flex align-items-center justify-content-center">
                                                            <svg class="icon icon-eye-light">
                                                                  <use xlink:href="#icon-eye-light"></use>
                                                            </svg>
                                                      </span>
                                                </a>
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm wishlist"
                                                      href="#" data-bs-toggle="tooltip" data-bs-placement="top"
                                                      data-bs-title="Add To Wishlist">
                                                      <svg class="icon icon-star-light">
                                                            <use xlink:href="#icon-star-light"></use>
                                                      </svg>
                                                </a>
                                                <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm compare"
                                                      href="shop/compare.html" data-bs-toggle="tooltip"
                                                      data-bs-placement="top" data-bs-title="Compare">
                                                      <svg class="icon icon-arrows-left-right-light">
                                                            <use xlink:href="#icon-arrows-left-right-light"></use>
                                                      </svg>
                                                </a>
                                          </div>
                                    </figure>
                                    <div class="card-body text-center p-0">
                                          <span
                                                class="d-flex align-items-center price text-body-emphasis fw-bold justify-content-center mb-3 fs-6">
                                                <del class=" text-body fw-500 me-4 fs-13px">₹39.00</del>
                                                <ins class="text-decoration-none">₹29.00</ins></span>
                                          <h4
                                                class="product-title card-title text-primary-hover text-body-emphasis fs-15px fw-500 mb-3">
                                                <a class="text-decoration-none text-reset"
                                                      href="shop/product-details-v1.html">Enriched Hand Wash</a>
                                          </h4>
                                          <div class="d-flex align-items-center fs-12px justify-content-center">
                                                <div class="rating">
                                                      <div class="empty-stars">
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star-o">
                                                                        <use xlink:href="#star-o"></use>
                                                                  </svg>
                                                            </span>
                                                      </div>
                                                      <div class="filled-stars" style="width: 80%">
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                            <span class="star">
                                                                  <svg class="icon star text-primary">
                                                                        <use xlink:href="#star"></use>
                                                                  </svg>
                                                            </span>
                                                      </div>
                                                </div><span class="reviews ms-4 pt-3 fs-14px">2947 reviews</span>
                                          </div>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
      <section class="container container-xxl">
            <div class="row gy-30px">
                  <div class="col-lg-6" data-animate="fadeInUp">
                        <div class="card border-0 rounded-0 banner-01 hover-zoom-in hover-shine">
                              <img class="lazy-image object-fit-cover card-img light-mode-img" src="#"
                                    data-src="./assets/images/banner/banner-01.jpg" width="690" height="420"
                                    alt="Intensive Glow C&#43; Serum">
                              <img class="lazy-image dark-mode-img object-fit-cover card-img" src="#"
                                    data-src="./assets/images/banner/banner-white-01.jpg" width="690" height="420"
                                    alt="Intensive Glow C&#43; Serum">
                              <div class="card-img-overlay d-inline-flex flex-column p-md-12 m-md-2 p-8">
                                    <h6 class="card-subtitle ls-1 fs-15px mb-5 fw-semibold text-body-calculate">
                                          NEW COLLECTION</h6>
                                    <h3 class="card-title lh-45px mw-md-60 pe-xl-15  fs-3 pe-0">Intensive Glow
                                          C&#43; Serum</h3>
                                    <div class="mt-7"><a href="grid-layout.php" class="btn btn-white px-6 shadow-sm">Explore
                                                More</a></div>
                              </div>
                        </div>
                  </div>
                  <div class="col-lg-6" data-animate="fadeInUp">
                        <div class="card border-0 rounded-0 banner-01 hover-zoom-in hover-shine">
                              <img class="lazy-image object-fit-cover card-img light-mode-img" src="#"
                                    data-src="./assets/images/banner/banner-02.jpg" width="690" height="420"
                                    alt="25% off Everything">
                              <img class="lazy-image dark-mode-img object-fit-cover card-img" src="#"
                                    data-src="./assets/images/banner/banner-white-02.jpg" width="690" height="420"
                                    alt="25% off Everything">
                              <div class="card-img-overlay d-inline-flex flex-column p-md-12 m-md-2 p-8">
                                    <h3 class="card-title lh-45px fs-3 pe-15">25% off Everything</h3>
                                    <p class="card-text fs-15px text-body-emphasis mw-md-60 pe-xl-20">Makeup with
                                          extended range in colors for every human.</p>
                                    <div class="mt-7"><a href="grid-layout.php" class="btn btn-white shadow-sm">Shop Sale</a>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
      <section class="pt-12 pb-lg-13 pb-13">
            <div class="container container-xxl">
                  <div class="row">
                        <div class="col-xl-3 col-md-6" data-animate="fadeInUp">
                              <div class="icon-box icon-box-style-1 card border-0 text-center">
                                    <div class="icon-box-icon card-img fs-70px text-primary">
                                          <svg class="icon">
                                                <use xlink:href="#icon-box-01"></use>
                                          </svg>
                                    </div>
                                    <div class="icon-box-content card-body pt-4">
                                          <h3 class="icon-box-title card-title fs-5 mb-4 pb-2">Free Shipping</h3>
                                          <p class="icon-box-desc card-text fs-18px mb-0">Free Shipping for orders
                                                over ₹130</p>
                                    </div>
                              </div>
                        </div>
                        <div class="col-xl-3 col-md-6" data-animate="fadeInUp">
                              <div class="icon-box icon-box-style-1 card border-0 text-center">
                                    <div class="icon-box-icon card-img fs-70px text-primary">
                                          <svg class="icon">
                                                <use xlink:href="#icon-box-02"></use>
                                          </svg>
                                    </div>
                                    <div class="icon-box-content card-body pt-4">
                                          <h3 class="icon-box-title card-title fs-5 mb-4 pb-2">Returns</h3>
                                          <p class="icon-box-desc card-text fs-18px mb-0">Within 30 days for an
                                                exchange.</p>
                                    </div>
                              </div>
                        </div>
                        <div class="col-xl-3 col-md-6" data-animate="fadeInUp">
                              <div class="icon-box icon-box-style-1 card border-0 text-center">
                                    <div class="icon-box-icon card-img fs-70px text-primary">
                                          <svg class="icon">
                                                <use xlink:href="#icon-box-03"></use>
                                          </svg>
                                    </div>
                                    <div class="icon-box-content card-body pt-4">
                                          <h3 class="icon-box-title card-title fs-5 mb-4 pb-2">Online Support</h3>
                                          <p class="icon-box-desc card-text fs-18px mb-0">24 hours a day, 7 days a
                                                week</p>
                                    </div>
                              </div>
                        </div>
                        <div class="col-xl-3 col-md-6" data-animate="fadeInUp">
                              <div class="icon-box icon-box-style-1 card border-0 text-center">
                                    <div class="icon-box-icon card-img fs-70px text-primary">
                                          <svg class="icon">
                                                <use xlink:href="#icon-box-04"></use>
                                          </svg>
                                    </div>
                                    <div class="icon-box-content card-body pt-4">
                                          <h3 class="icon-box-title card-title fs-5 mb-4 pb-2">Flexible Payment
                                          </h3>
                                          <p class="icon-box-desc card-text fs-18px mb-0">Pay with Multiple Credit
                                                Cards</p>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
      <section class="pt-14 pb-16 py-lg-19 bg-section-2">
            <div class="container container-xxl">
                  <div class="text-center" data-animate="fadeInUp">
                        <h2 class="mb-6">As seen in</h2>
                  </div>
                  <div class="slick-slider mt-12"
                        data-slick-options="{&quot;slidesToShow&quot;: 3,&quot;dots&quot;:false,&quot;arrows&quot;:false,&quot;responsive&quot;:[{&quot;breakpoint&quot;: 992,&quot;settings&quot;: {&quot;slidesToShow&quot;: 2,&quot;dots&quot;:true}},{&quot;breakpoint&quot;: 768,&quot;settings&quot;: {&quot;slidesToShow&quot;: 2,&quot;dots&quot;:true}},{&quot;breakpoint&quot;: 576,&quot;settings&quot;: {&quot;slidesToShow&quot;: 1,&quot;dots&quot;:true}}]}">
                        <div data-animate="fadeInUp">
                              <div class="bg-transparent text-center">
                                    <img class="lazy-image w-auto mx-auto mb-6 light-mode-img" src="#"
                                          data-src="./assets/images/testimonial/testimonial-03.png" width="150"
                                          height="82"
                                          alt="Also the customer service is phenomenal. I would purchase again.">
                                    <img class="lazy-image dark-mode-img w-auto mx-auto mb-6" src="#"
                                          data-src="./assets/images/testimonial/testimonial-white-03.png" width="150"
                                          height="82"
                                          alt="Also the customer service is phenomenal. I would purchase again.">
                                    <p class="fs-5 fw-semibold mx-xl-9 px-xl-2 mb-0 text-body-emphasis">“Also the
                                          customer service is phenomenal. I would purchase again.“</p>
                              </div>
                        </div>
                        <div data-animate="fadeInUp">
                              <div class="bg-transparent text-center">
                                    <img class="lazy-image w-auto mx-auto mb-6 light-mode-img" src="#"
                                          data-src="./assets/images/testimonial/testimonial-02.png" width="150"
                                          height="82" alt="Great product line. Very attentive staff to deal with.">
                                    <img class="lazy-image dark-mode-img w-auto mx-auto mb-6" src="#"
                                          data-src="./assets/images/testimonial/testimonial-white-02.png" width="150"
                                          height="82" alt="Great product line. Very attentive staff to deal with.">
                                    <p class="fs-5 fw-semibold mx-xl-9 px-xl-2 mb-0 text-body-emphasis">“Great
                                          product line. Very attentive staff to deal with.“</p>
                              </div>
                        </div>
                        <div data-animate="fadeInUp">
                              <div class="bg-transparent text-center">
                                    <img class="lazy-image w-auto mx-auto mb-6 light-mode-img" src="#"
                                          data-src="./assets/images/testimonial/testimonial-01.png" width="150"
                                          height="82"
                                          alt="Looking to affordably upgrade your everyday dinnerware? Look no further than e.Space">
                                    <img class="lazy-image dark-mode-img w-auto mx-auto mb-6" src="#"
                                          data-src="./assets/images/testimonial/testimonial-white-01.png" width="150"
                                          height="82"
                                          alt="Looking to affordably upgrade your everyday dinnerware? Look no further than e.Space">
                                    <p class="fs-5 fw-semibold mx-xl-9 px-xl-2 mb-0 text-body-emphasis">“Looking
                                          to affordably upgrade your everyday dinnerware? Look no further than
                                          e.Space“</p>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
      <section>
            <div class="container container-xxl pt-lg-19 pt-14 mb-2">
                  <div class="mb-11 mt-2 pt-1 pb-3 text-center" data-animate="fadeInUp">
                        <h2 class="mb-5">Customer Favorite Beauty Essentials</h2>
                        <p class="fs-18px mb-0 mw-xl-30 mw-lg-50 mw-md-75 ms-auto me-auto">Made using clean,
                              non-toxic ingredients, our products are designed for everyone.</p>
                  </div>
                  <div class="row">
                        <div class="col-lg-5 mb-10 mb-lg-0" data-animate="fadeInUp">
                              <div class="card border-0 rounded-0 hover-zoom-in hover-shine">
                                    <img class="lazy-image w-100 img-fluid card-img object-fit-cover banner-02 light-mode-img"
                                          src="#" data-src="./assets/images/banner/banner-33.jpg" width="570"
                                          height="913" alt="Empower Yourself">
                                    <img class="lazy-image dark-mode-img w-100 img-fluid card-img object-fit-cover banner-02"
                                          src="#" data-src="./assets/images/banner/banner-white-33.jpg" width="570"
                                          height="913" alt="Empower Yourself">
                                    <div
                                          class="card-img-overlay p-12 m-2 d-inline-flex flex-column justify-content-end">
                                          <h3 class="card-title mb-0 fs-2 text-white">Empower Yourself</h3>
                                          <p class="card-text mb-0 fs-18px text-white mt-5">Get the skin you want
                                                to feel</p>
                                          <div class="mt-10 pt-2">
                                                <a href="grid-layout.php" class="btn btn-white">Explore More</a>
                                          </div>
                                    </div>
                              </div>
                        </div>
                        <div class="col-lg-7">
                              <div class="row gy-11">
                                    <div class="col-md-4 col-sm-6 col-12">
                                          <div class="card card-product grid-2 bg-transparent border-0"
                                                data-animate="fadeInUp">
                                                <figure class="card-img-top position-relative mb-7 overflow-hidden">
                                                      <a href="shop/product-details-v1.html"
                                                            class="hover-zoom-in d-block" title="Enriched Duo">
                                                            <img src="#"
                                                                  data-src="./assets/images/products/product-01-330x440.jpg"
                                                                  class="img-fluid lazy-image w-100" alt="Enriched Duo"
                                                                  width="330" height="440">
                                                      </a>
                                                      <div
                                                            class="position-absolute d-flex z-index-2 product-actions  vertical">
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm quick-view sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Quick View">
                                                                  <span data-bs-toggle="modal"
                                                                        data-bs-target="#quickViewModal"
                                                                        class="d-flex align-items-center justify-content-center">
                                                                        <svg class="icon icon-eye-light">
                                                                              <use xlink:href="#icon-eye-light">
                                                                              </use>
                                                                        </svg>
                                                                  </span>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm wishlist sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left"
                                                                  data-bs-title="Add To Wishlist">
                                                                  <svg class="icon icon-star-light">
                                                                        <use xlink:href="#icon-star-light"></use>
                                                                  </svg>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm compare sm"
                                                                  href="shop/compare.html" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Compare">
                                                                  <svg class="icon icon-arrows-left-right-light">
                                                                        <use xlink:href="#icon-arrows-left-right-light">
                                                                        </use>
                                                                  </svg>
                                                            </a>
                                                      </div><a href="#"
                                                            class="btn btn-add-to-cart btn-dark btn-hover-bg-primary btn-hover-border-primary position-absolute z-index-2 text-nowrap btn-sm px-6 py-3 lh-2">Add
                                                            To Cart</a>
                                                </figure>
                                                <div class="card-body text-center p-0">
                                                      <span
                                                            class="d-flex align-items-center price text-body-emphasis fw-bold justify-content-center mb-3 fs-6">₹29.00</span>
                                                      <h4
                                                            class="product-title card-title text-primary-hover text-body-emphasis fs-15px fw-500 mb-3">
                                                            <a class="text-decoration-none text-reset"
                                                                  href="shop/product-details-v1.html">Enriched
                                                                  Duo</a>
                                                      </h4>
                                                      <div
                                                            class="d-flex align-items-center fs-12px justify-content-center">
                                                            <div class="rating">
                                                                  <div class="empty-stars">
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                                  <div class="filled-stars" style="width: 100%">
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                            </div><span class="reviews ms-4 pt-3 fs-14px">2947
                                                                  reviews</span>
                                                      </div>
                                                </div>
                                          </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-12">
                                          <div class="card card-product grid-2 bg-transparent border-0"
                                                data-animate="fadeInUp">
                                                <figure class="card-img-top position-relative mb-7 overflow-hidden">
                                                      <a href="shop/product-details-v1.html"
                                                            class="hover-zoom-in d-block" title="Shield Spray">
                                                            <img src="#"
                                                                  data-src="./assets/images/products/product-02-330x440.jpg"
                                                                  class="img-fluid lazy-image w-100" alt="Shield Spray"
                                                                  width="330" height="440">
                                                      </a>
                                                      <div
                                                            class="position-absolute d-flex z-index-2 product-actions  vertical">
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm quick-view sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Quick View">
                                                                  <span data-bs-toggle="modal"
                                                                        data-bs-target="#quickViewModal"
                                                                        class="d-flex align-items-center justify-content-center">
                                                                        <svg class="icon icon-eye-light">
                                                                              <use xlink:href="#icon-eye-light">
                                                                              </use>
                                                                        </svg>
                                                                  </span>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm wishlist sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left"
                                                                  data-bs-title="Add To Wishlist">
                                                                  <svg class="icon icon-star-light">
                                                                        <use xlink:href="#icon-star-light"></use>
                                                                  </svg>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm compare sm"
                                                                  href="shop/compare.html" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Compare">
                                                                  <svg class="icon icon-arrows-left-right-light">
                                                                        <use xlink:href="#icon-arrows-left-right-light">
                                                                        </use>
                                                                  </svg>
                                                            </a>
                                                      </div><a href="#"
                                                            class="btn btn-add-to-cart btn-dark btn-hover-bg-primary btn-hover-border-primary position-absolute z-index-2 text-nowrap btn-sm px-6 py-3 lh-2">Add
                                                            To Cart</a>
                                                </figure>
                                                <div class="card-body text-center p-0">
                                                      <span
                                                            class="d-flex align-items-center price text-body-emphasis fw-bold justify-content-center mb-3 fs-6">₹29.00</span>
                                                      <h4
                                                            class="product-title card-title text-primary-hover text-body-emphasis fs-15px fw-500 mb-3">
                                                            <a class="text-decoration-none text-reset"
                                                                  href="shop/product-details-v1.html">Shield
                                                                  Spray</a>
                                                      </h4>
                                                      <div
                                                            class="d-flex align-items-center fs-12px justify-content-center">
                                                            <div class="rating">
                                                                  <div class="empty-stars">
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                                  <div class="filled-stars" style="width: 100%">
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                            </div><span class="reviews ms-4 pt-3 fs-14px">2947
                                                                  reviews</span>
                                                      </div>
                                                </div>
                                          </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-12">
                                          <div class="card card-product grid-2 bg-transparent border-0"
                                                data-animate="fadeInUp">
                                                <figure class="card-img-top position-relative mb-7 overflow-hidden">
                                                      <a href="shop/product-details-v1.html"
                                                            class="hover-zoom-in d-block" title="Vital Eye Cream">
                                                            <img src="#"
                                                                  data-src="./assets/images/products/product-05-330x440.jpg"
                                                                  class="img-fluid lazy-image w-100"
                                                                  alt="Vital Eye Cream" width="330" height="440">
                                                      </a>
                                                      <div class="position-absolute product-flash z-index-2 ">
                                                            <span
                                                                  class="badge badge-product-flash on-sale bg-primary">-26%</span>
                                                      </div>
                                                      <div
                                                            class="position-absolute d-flex z-index-2 product-actions  vertical">
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm quick-view sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Quick View">
                                                                  <span data-bs-toggle="modal"
                                                                        data-bs-target="#quickViewModal"
                                                                        class="d-flex align-items-center justify-content-center">
                                                                        <svg class="icon icon-eye-light">
                                                                              <use xlink:href="#icon-eye-light">
                                                                              </use>
                                                                        </svg>
                                                                  </span>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm wishlist sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left"
                                                                  data-bs-title="Add To Wishlist">
                                                                  <svg class="icon icon-star-light">
                                                                        <use xlink:href="#icon-star-light"></use>
                                                                  </svg>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm compare sm"
                                                                  href="shop/compare.html" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Compare">
                                                                  <svg class="icon icon-arrows-left-right-light">
                                                                        <use xlink:href="#icon-arrows-left-right-light">
                                                                        </use>
                                                                  </svg>
                                                            </a>
                                                      </div><a href="#"
                                                            class="btn btn-add-to-cart btn-dark btn-hover-bg-primary btn-hover-border-primary position-absolute z-index-2 text-nowrap btn-sm px-6 py-3 lh-2">Add
                                                            To Cart</a>
                                                </figure>
                                                <div class="card-body text-center p-0">
                                                      <span
                                                            class="d-flex align-items-center price text-body-emphasis fw-bold justify-content-center mb-3 fs-6">
                                                            <del class=" text-body fw-500 me-4 fs-13px">₹39.00</del>
                                                            <ins class="text-decoration-none">₹29.00</ins></span>
                                                      <h4
                                                            class="product-title card-title text-primary-hover text-body-emphasis fs-15px fw-500 mb-3">
                                                            <a class="text-decoration-none text-reset"
                                                                  href="shop/product-details-v1.html">Vital Eye
                                                                  Cream</a>
                                                      </h4>
                                                      <div
                                                            class="d-flex align-items-center fs-12px justify-content-center">
                                                            <div class="rating">
                                                                  <div class="empty-stars">
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                                  <div class="filled-stars" style="width: 80%">
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                            </div><span class="reviews ms-4 pt-3 fs-14px">2947
                                                                  reviews</span>
                                                      </div>
                                                </div>
                                          </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-12">
                                          <div class="card card-product grid-2 bg-transparent border-0"
                                                data-animate="fadeInUp">
                                                <figure class="card-img-top position-relative mb-7 overflow-hidden">
                                                      <a href="shop/product-details-v1.html"
                                                            class="hover-zoom-in d-block" title="Supreme Moisture Mask">
                                                            <img src="#"
                                                                  data-src="./assets/images/products/product-03-330x440.jpg"
                                                                  class="img-fluid lazy-image w-100"
                                                                  alt="Supreme Moisture Mask" width="330" height="440">
                                                      </a>
                                                      <div class="position-absolute product-flash z-index-2 ">
                                                            <span
                                                                  class="badge badge-product-flash on-sale bg-primary">-26%</span>
                                                      </div>
                                                      <div
                                                            class="position-absolute d-flex z-index-2 product-actions  vertical">
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm quick-view sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Quick View">
                                                                  <span data-bs-toggle="modal"
                                                                        data-bs-target="#quickViewModal"
                                                                        class="d-flex align-items-center justify-content-center">
                                                                        <svg class="icon icon-eye-light">
                                                                              <use xlink:href="#icon-eye-light">
                                                                              </use>
                                                                        </svg>
                                                                  </span>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm wishlist sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left"
                                                                  data-bs-title="Add To Wishlist">
                                                                  <svg class="icon icon-star-light">
                                                                        <use xlink:href="#icon-star-light"></use>
                                                                  </svg>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm compare sm"
                                                                  href="shop/compare.html" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Compare">
                                                                  <svg class="icon icon-arrows-left-right-light">
                                                                        <use xlink:href="#icon-arrows-left-right-light">
                                                                        </use>
                                                                  </svg>
                                                            </a>
                                                      </div><a href="#"
                                                            class="btn btn-add-to-cart btn-dark btn-hover-bg-primary btn-hover-border-primary position-absolute z-index-2 text-nowrap btn-sm px-6 py-3 lh-2">Add
                                                            To Cart</a>
                                                </figure>
                                                <div class="card-body text-center p-0">
                                                      <span
                                                            class="d-flex align-items-center price text-body-emphasis fw-bold justify-content-center mb-3 fs-6">
                                                            <del class=" text-body fw-500 me-4 fs-13px">₹39.00</del>
                                                            <ins class="text-decoration-none">₹29.00</ins></span>
                                                      <h4
                                                            class="product-title card-title text-primary-hover text-body-emphasis fs-15px fw-500 mb-3">
                                                            <a class="text-decoration-none text-reset"
                                                                  href="shop/product-details-v1.html">Supreme
                                                                  Moisture Mask</a>
                                                      </h4>
                                                      <div
                                                            class="d-flex align-items-center fs-12px justify-content-center">
                                                            <div class="rating">
                                                                  <div class="empty-stars">
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                                  <div class="filled-stars" style="width: 80%">
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                            </div><span class="reviews ms-4 pt-3 fs-14px">2947
                                                                  reviews</span>
                                                      </div>
                                                </div>
                                          </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-12">
                                          <div class="card card-product grid-2 bg-transparent border-0"
                                                data-animate="fadeInUp">
                                                <figure class="card-img-top position-relative mb-7 overflow-hidden">
                                                      <a href="shop/product-details-v1.html"
                                                            class="hover-zoom-in d-block"
                                                            title="Supreme Polishing Treatment">
                                                            <img src="#"
                                                                  data-src="./assets/images/products/product-15-330x440.jpg"
                                                                  class="img-fluid lazy-image w-100"
                                                                  alt="Supreme Polishing Treatment" width="330"
                                                                  height="440">
                                                      </a>
                                                      <div
                                                            class="position-absolute d-flex z-index-2 product-actions  vertical">
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm quick-view sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Quick View">
                                                                  <span data-bs-toggle="modal"
                                                                        data-bs-target="#quickViewModal"
                                                                        class="d-flex align-items-center justify-content-center">
                                                                        <svg class="icon icon-eye-light">
                                                                              <use xlink:href="#icon-eye-light">
                                                                              </use>
                                                                        </svg>
                                                                  </span>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm wishlist sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left"
                                                                  data-bs-title="Add To Wishlist">
                                                                  <svg class="icon icon-star-light">
                                                                        <use xlink:href="#icon-star-light"></use>
                                                                  </svg>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm compare sm"
                                                                  href="shop/compare.html" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Compare">
                                                                  <svg class="icon icon-arrows-left-right-light">
                                                                        <use xlink:href="#icon-arrows-left-right-light">
                                                                        </use>
                                                                  </svg>
                                                            </a>
                                                      </div><a href="#"
                                                            class="btn btn-add-to-cart btn-dark btn-hover-bg-primary btn-hover-border-primary position-absolute z-index-2 text-nowrap btn-sm px-6 py-3 lh-2">Add
                                                            To Cart</a>
                                                </figure>
                                                <div class="card-body text-center p-0">
                                                      <span
                                                            class="d-flex align-items-center price text-body-emphasis fw-bold justify-content-center mb-3 fs-6">₹29.00</span>
                                                      <h4
                                                            class="product-title card-title text-primary-hover text-body-emphasis fs-15px fw-500 mb-3">
                                                            <a class="text-decoration-none text-reset"
                                                                  href="shop/product-details-v1.html">Supreme
                                                                  Polishing Treatment</a>
                                                      </h4>
                                                      <div
                                                            class="d-flex align-items-center fs-12px justify-content-center">
                                                            <div class="rating">
                                                                  <div class="empty-stars">
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                                  <div class="filled-stars" style="width: 100%">
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                            </div><span class="reviews ms-4 pt-3 fs-14px">2947
                                                                  reviews</span>
                                                      </div>
                                                </div>
                                          </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-12">
                                          <div class="card card-product grid-2 bg-transparent border-0"
                                                data-animate="fadeInUp">
                                                <figure class="card-img-top position-relative mb-7 overflow-hidden">
                                                      <a href="shop/product-details-v1.html"
                                                            class="hover-zoom-in d-block"
                                                            title="Scalp Moisturizing Cream">
                                                            <img src="#"
                                                                  data-src="./assets/images/products/product-06-330x440.jpg"
                                                                  class="img-fluid lazy-image w-100"
                                                                  alt="Scalp Moisturizing Cream" width="330"
                                                                  height="440">
                                                      </a>
                                                      <div
                                                            class="position-absolute d-flex z-index-2 product-actions  vertical">
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm quick-view sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Quick View">
                                                                  <span data-bs-toggle="modal"
                                                                        data-bs-target="#quickViewModal"
                                                                        class="d-flex align-items-center justify-content-center">
                                                                        <svg class="icon icon-eye-light">
                                                                              <use xlink:href="#icon-eye-light">
                                                                              </use>
                                                                        </svg>
                                                                  </span>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm wishlist sm"
                                                                  href="#" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left"
                                                                  data-bs-title="Add To Wishlist">
                                                                  <svg class="icon icon-star-light">
                                                                        <use xlink:href="#icon-star-light"></use>
                                                                  </svg>
                                                            </a>
                                                            <a class="text-body-emphasis bg-body bg-dark-hover text-light-hover rounded-circle square product-action shadow-sm compare sm"
                                                                  href="shop/compare.html" data-bs-toggle="tooltip"
                                                                  data-bs-placement="left" data-bs-title="Compare">
                                                                  <svg class="icon icon-arrows-left-right-light">
                                                                        <use xlink:href="#icon-arrows-left-right-light">
                                                                        </use>
                                                                  </svg>
                                                            </a>
                                                      </div><a href="#"
                                                            class="btn btn-add-to-cart btn-dark btn-hover-bg-primary btn-hover-border-primary position-absolute z-index-2 text-nowrap btn-sm px-6 py-3 lh-2">Add
                                                            To Cart</a>
                                                </figure>
                                                <div class="card-body text-center p-0">
                                                      <span
                                                            class="d-flex align-items-center price text-body-emphasis fw-bold justify-content-center mb-3 fs-6">₹29.00</span>
                                                      <h4
                                                            class="product-title card-title text-primary-hover text-body-emphasis fs-15px fw-500 mb-3">
                                                            <a class="text-decoration-none text-reset"
                                                                  href="shop/product-details-v1.html">Scalp
                                                                  Moisturizing Cream</a>
                                                      </h4>
                                                      <div
                                                            class="d-flex align-items-center fs-12px justify-content-center">
                                                            <div class="rating">
                                                                  <div class="empty-stars">
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star-o">
                                                                                    <use xlink:href="#star-o">
                                                                                    </use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                                  <div class="filled-stars" style="width: 100%">
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                        <span class="star">
                                                                              <svg class="icon star text-primary">
                                                                                    <use xlink:href="#star"></use>
                                                                              </svg>
                                                                        </span>
                                                                  </div>
                                                            </div><span class="reviews ms-4 pt-3 fs-14px">2947
                                                                  reviews</span>
                                                      </div>
                                                </div>
                                          </div>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
      <section class="pt-14 pb-md-12 pb-8 pb-lg-17 pt-lg-21">
            <div class="container container-xxl">
                  <div class="text-center" data-animate="fadeInUp">
                        <h2 class="mb-6">More to Discover</h2>
                        <p class="fs-18px w-lg-60 w-xl-40 mx-md-16 mx-lg-auto mb-13">Our bundles were designed to
                              conveniently package your tanning essentials while saving you money.</p>
                  </div>
                  <div class="row">
                        <div class="col-md-6 mb-8 mb-md-0" data-animate="fadeInUp">
                              <div class="card border-0">
                                    <div class="image-box-4">
                                          <img class="lazy-image img-fluid lazy-image light-mode-img" src="#"
                                                data-src="./assets/images/image-box/image-box-10-1.jpg" width="960"
                                                height="640" alt>
                                          <img class="lazy-image dark-mode-img img-fluid lazy-image" src="#"
                                                data-src="./assets/images/image-box/image-box-white-10-1.jpg"
                                                width="960" height="640" alt>
                                    </div>
                                    <div class="card-body text-body-emphasis text-center pt-9 mt-2">
                                          <h5 class="card-titletext-decoration-none fs-4 mb-4 d-block fw-semibold">
                                                <a class="color-inherit text-decoration-none" href="#">Summer
                                                      Collection</a>
                                          </h5>
                                          <a href="grid-layout.php" title="Shop now"
                                                class="btn btn-link fw-semibold text-body-emphasis">Shop now <i
                                                      class="far fa-arrow-right fs-14px ps-2 ms-1"></i></a>
                                    </div>
                              </div>
                        </div>
                        <div class="col-md-6 mb-8 mb-md-0" data-animate="fadeInUp">
                              <div class="card border-0">
                                    <div class="image-box-4">
                                          <img class="lazy-image img-fluid lazy-image light-mode-img" src="#"
                                                data-src="./assets/images/image-box/image-box-12.jpg" width="960"
                                                height="640" alt>
                                          <img class="lazy-image dark-mode-img img-fluid lazy-image" src="#"
                                                data-src="./assets/images/image-box/image-box-white-12.jpg" width="960"
                                                height="640" alt>
                                    </div>
                                    <div class="card-body text-body-emphasis text-center pt-9 mt-2">
                                          <h5 class="card-titletext-decoration-none fs-4 mb-4 d-block fw-semibold">
                                                <a class="color-inherit text-decoration-none" href="#">Summer
                                                      Collection</a>
                                          </h5>
                                          <a href="grid-layout.php" title="Shop now"
                                                class="btn btn-link fw-semibold text-body-emphasis">Read more <i
                                                      class="far fa-arrow-right fs-14px ps-2 ms-1"></i></a>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
      <section class="pb-10">
            <div class="container-fluid">
                  <div class="px-md-6">
                        <div class="mx-n6 slick-slider"
                              data-slick-options="{&quot;slidesToShow&quot;: 5,&quot;infinite&quot;:false,&quot;autoplay&quot;:false,&quot;dots&quot;:false,&quot;arrows&quot;:false,&quot;responsive&quot;:[{&quot;breakpoint&quot;: 1366,&quot;settings&quot;: {&quot;slidesToShow&quot;:5 }},{&quot;breakpoint&quot;: 992,&quot;settings&quot;: {&quot;slidesToShow&quot;:2}},{&quot;breakpoint&quot;: 768,&quot;settings&quot;: {&quot;slidesToShow&quot;: 3}},{&quot;breakpoint&quot;: 576,&quot;settings&quot;: {&quot;slidesToShow&quot;: 2}}]}">
                              <div class="px-6" data-animate="fadeInUp">
                                    <a href="assets/images/instagram/instagram-01.jpg" title="instagram-01"
                                          data-gallery="instagram"
                                          class=" hover-zoom-in hover-shine  card-img-overlay-hover hover-zoom-in hover-shine d-block">
                                          <img class="lazy-image img-fluid w-100" width="314" height="314"
                                                data-src="./assets/images/instagram/instagram-01-320x320.jpg"
                                                alt="instagram-01" src="#">
                                          <span class="card-img-overlay bg-dark bg-opacity-30"></span>
                                    </a>
                              </div>
                              <div class="px-6" data-animate="fadeInUp">
                                    <a href="assets/images/instagram/instagram-02.jpg" title="instagram-02"
                                          data-gallery="instagram"
                                          class=" hover-zoom-in hover-shine  card-img-overlay-hover hover-zoom-in hover-shine d-block">
                                          <img class="lazy-image img-fluid w-100" width="314" height="314"
                                                data-src="./assets/images/instagram/instagram-02-320x320.jpg"
                                                alt="instagram-02" src="#">
                                          <span class="card-img-overlay bg-dark bg-opacity-30"></span>
                                    </a>
                              </div>
                              <div class="px-6" data-animate="fadeInUp">
                                    <a href="assets/images/instagram/instagram-03.jpg" title="instagram-03"
                                          data-gallery="instagram"
                                          class=" hover-zoom-in hover-shine  card-img-overlay-hover hover-zoom-in hover-shine d-block">
                                          <img class="lazy-image img-fluid w-100" width="314" height="314"
                                                data-src="./assets/images/instagram/instagram-03-320x320.jpg"
                                                alt="instagram-03" src="#">
                                          <span class="card-img-overlay bg-dark bg-opacity-30"></span>
                                    </a>
                              </div>
                              <div class="px-6" data-animate="fadeInUp">
                                    <a href="assets/images/instagram/instagram-04.jpg" title="instagram-04"
                                          data-gallery="instagram"
                                          class=" hover-zoom-in hover-shine  card-img-overlay-hover hover-zoom-in hover-shine d-block">
                                          <img class="lazy-image img-fluid w-100" width="314" height="314"
                                                data-src="./assets/images/instagram/instagram-04-320x320.jpg"
                                                alt="instagram-04" src="#">
                                          <span class="card-img-overlay bg-dark bg-opacity-30"></span>
                                    </a>
                              </div>
                              <div class="px-6" data-animate="fadeInUp">
                                    <a href="assets/images/instagram/instagram-05.jpg" title="instagram-05"
                                          data-gallery="instagram"
                                          class=" hover-zoom-in hover-shine  card-img-overlay-hover hover-zoom-in hover-shine d-block">
                                          <img class="lazy-image img-fluid w-100" width="314" height="314"
                                                data-src="./assets/images/instagram/instagram-05-320x320.jpg"
                                                alt="instagram-05" src="#">
                                          <span class="card-img-overlay bg-dark bg-opacity-30"></span>
                                    </a>
                              </div>
                              <div class="px-6" data-animate="fadeInUp">
                                    <a href="assets/images/instagram/instagram-06.jpg" title="instagram-06"
                                          data-gallery="instagram"
                                          class=" hover-zoom-in hover-shine  card-img-overlay-hover hover-zoom-in hover-shine d-block">
                                          <img class="lazy-image img-fluid w-100" width="314" height="314"
                                                data-src="./assets/images/instagram/instagram-06-320x320.jpg"
                                                alt="instagram-06" src="#">
                                          <span class="card-img-overlay bg-dark bg-opacity-30"></span>
                                    </a>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
</main>


<?php include_once "footer.php"; ?>