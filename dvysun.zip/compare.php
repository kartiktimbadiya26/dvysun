<?php include_once "header.php"; ?>
<main id="content" class="wrapper layout-page">
      <section class="z-index-2 position-relative pb-2 mb-12">
            <div class="bg-body-secondary mb-3">
                  <div class="container">
                        <nav class="py-4 lh-30px" aria-label="breadcrumb">
                              <ol class="breadcrumb justify-content-center py-1 mb-0">
                                    <li class="breadcrumb-item"><a title="Home" href="index.php">Home</a></li>
                                    <!-- <li class="breadcrumb-item"><a title="Shop" href="shop-layout-v2.html">Shop</a></li> -->
                                    <li class="breadcrumb-item active" aria-current="page">Compare</li>
                              </ol>
                        </nav>
                  </div>
            </div>
      </section>
      <section class="container container-xxl pb-15 pb-lg-17">
            <div class="text-center">
                  <h2 class="my-12">Compare</h2>
            </div>
            <div class="table-responsive-xl">
                  <table class="table table-bordered">
                        <thead>
                              <tr>
                                    <th scope="col" class="text-center align-middle bg-body-tertiary p-5">
                                          <span class="fs-6 text-body-emphasis fw-500">Products</span>
                                    </th>
                                    <th scope="col" class="pb-9">
                                          <p class="fs-18px text-center mt-4 mb-6 text-body-emphasis fw-semibold">
                                                Priming Moisturize</p>
                                          <a href="#" class="text-center d-block">
                                                <img src="#" data-src="../assets/images/products/product-01-210x280.jpg"
                                                      class="lazy-image" alt="Priming Moisturize"
                                                      style="max-width: 210px" width="210" height="280">
                                          </a>
                                    </th>
                                    <th scope="col" class="pb-9">
                                          <p class="fs-18px text-center mt-4 mb-6 text-body-emphasis fw-semibold">
                                                Priming Moisturizer Rich</p>
                                          <a href="#" class="text-center d-block">
                                                <img src="#" data-src="../assets/images/products/product-03-210x280.jpg"
                                                      class="lazy-image" alt="Priming Moisturize"
                                                      style="max-width: 210px" width="210" height="280">
                                          </a>
                                    </th>
                                    <th scope="col" class="pb-9">
                                          <p class="fs-18px text-center mt-4 mb-6 text-body-emphasis fw-semibold">
                                                Priming Moisturizer Balance</p>
                                          <a href="#" class="text-center d-block">
                                                <img src="#" data-src="../assets/images/products/product-10-210x280.jpg"
                                                      class="lazy-image" alt="Priming Moisturize"
                                                      style="max-width: 210px" width="210" height="280">
                                          </a>
                                    </th>
                              </tr>
                        </thead>
                        <tbody>
                              <tr>
                                    <th scope="col" class="text-center align-middle bg-body-tertiary p-5">
                                          <span class="fs-6 text-body-emphasis fw-500">Customer Rattings</span>
                                    </th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle">
                                          <div class="d-flex align-items-center">
                                                <span class="fw-semibold text-body-emphasis me-6 fs-15px">4.86</span>
                                                <ul class="list-inline mb-0 lh-0 flex-shrink-0">
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                </ul>
                                                <span
                                                      class="ms-4 fs-14px ps-4 lh-1 text-body border-start me-4 pe-2 fw-500">2947
                                                      reviews</span>
                                          </div>
                                    </th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle">
                                          <div class="d-flex align-items-center">
                                                <span class="fw-semibold text-body-emphasis me-6 fs-15px">4.75</span>
                                                <ul class="list-inline mb-0 lh-0 flex-shrink-0">
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                </ul>
                                                <span
                                                      class="ms-4 fs-14px ps-4 lh-1 text-body border-start me-4 pe-2 fw-500">47
                                                      reviews</span>
                                          </div>
                                    </th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle">
                                          <div class="d-flex align-items-center">
                                                <span class="fw-semibold text-body-emphasis me-6 fs-15px">4.91</span>
                                                <ul class="list-inline mb-0 lh-0 flex-shrink-0">
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                      <li class="list-inline-item fs-12px text-primary me-0"><i
                                                                  class="fas fa-star"></i></li>
                                                </ul>
                                                <span
                                                      class="ms-4 fs-14px ps-4 lh-1 text-body border-start me-4 pe-2 fw-500">296
                                                      reviews</span>
                                          </div>
                                    </th>
                              </tr>
                              <tr>
                                    <th scope="col" class="text-center align-middle bg-body-tertiary p-5">
                                          <span class="fs-6 text-body-emphasis fw-500">Price</span>
                                    </th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle">
                                          <span class="pe-3 fs-18px font-weight-bold text-body-emphasis">₹29.00</span>
                                          <span
                                                class="fs-15px fw-500 text-decoration-line-through text-body ">₹39.00</span>
                                          <span class="badge bg-primary ms-4 fs-6">-20%</span>
                                    </th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle">
                                          <span class="pe-3 fs-18px font-weight-bold text-body-emphasis">₹24.00</span>
                                          <span
                                                class="fs-15px fw-500 text-decoration-line-through text-body ">₹39.00</span>
                                          <span class="badge bg-primary ms-4 fs-6">-25%</span>
                                    </th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle">
                                          <span class="pe-3 fs-18px font-weight-bold text-body-emphasis">₹27.00</span>
                                    </th>
                              </tr>
                              <tr>
                                    <th scope="col" class="text-center align-middle bg-body-tertiary p-5">
                                          <span class="fs-6 text-body-emphasis fw-500">Stock Status</span>
                                    </th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle">
                                          <i
                                                class="fas fa-check fs-12px px-2 py-1 rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center"></i>
                                          <span class="fs-15px fw-500 ms-3">In stock</span>
                                    </th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle">
                                          <i
                                                class="fas fa-check fs-12px px-2 py-1 rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center"></i>
                                          <span class="fs-15px fw-500 ms-3">In stock</span>
                                    </th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle">
                                          <i
                                                class="fas fa-check fs-12px px-2 py-1 rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center"></i>
                                          <span class="fs-15px fw-500 ms-3">In stock</span>
                                    </th>
                              </tr>
                              <tr>
                                    <th scope="col" class="text-center align-middle bg-body-tertiary p-5">
                                          <span class="fs-6 text-body-emphasis fw-500">Shipping</span>
                                    </th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle fs-15px fw-500">Free shipping</th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle fs-15px fw-500">Free shipping</th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle fs-15px fw-500">Free shipping</th>
                              </tr>
                              <tr>
                                    <th scope="col" class="text-center align-middle bg-body-tertiary p-5">
                                          <span class="fs-6 text-body-emphasis fw-500">Sold</span>
                                    </th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle fs-15px fw-500">12546</th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle fs-15px fw-500">3489</th>
                                    <th scope="col" class="px-6 px-lg-9 align-middle fs-15px fw-500">2643</th>
                              </tr>
                              <tr>
                                    <th scope="col" class="bg-body-tertiary">
                                    </th>
                                    <th scope="col" class="px-6 text-center align-middle py-7">
                                          <a href="#" class="btn btn-dark btn-hover-bg-primary border-0 py-4">Add To
                                                Cart</a>
                                    </th>
                                    <th scope="col" class="px-6 text-center align-middle py-7">
                                          <a href="#" class="btn btn-dark btn-hover-bg-primary border-0 py-4">Add To
                                                Cart</a>
                                    </th>
                                    <th scope="col" class="px-6 text-center align-middle py-7">
                                          <a href="#" class="btn btn-dark btn-hover-bg-primary border-0 py-4">Add To
                                                Cart</a>
                                    </th>
                              </tr>
                        </tbody>
                  </table>
            </div>
      </section>
</main>
<?php include_once "footer.php"; ?>
