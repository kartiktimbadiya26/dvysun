<footer class="pt-6 pb-10 footer-dashboard mt-auto">
      <div class="row">
            <div class="col-sm-6 text-sm-start text-center">
                  <script>
                        document.write(new Date().getFullYear());
                  </script>
                  © DVYSUN - Beauty & Cosmetics Shop.
            </div>
            <div class="col-sm-6 text-sm-end text-center">
                  All rights reserved
            </div>
      </div>
</footer>