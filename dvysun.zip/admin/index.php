<?php
include_once "../database/db.php";
$error = false;
if (!isset($_SESSION["admin"])) {
      if (isset($_POST["submit"])) {
            $email = $_POST["email"];
            $password = $_POST["password"];
            $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ? AND password = ?");
            $stmt->bind_param("ss", $email, $password);
            $stmt->execute();
            $result = $stmt->get_result();
            // $data = $result->fetch_assoc();
            // print_r($data);
            // print_r($result->num_rows);
            if ($result->num_rows) {
                  $_SESSION["admin"] = true;
                  header("location: dashboard.php");
            } else {
                  $error = true;
            }
      }

} else {
      header("location:dashboard.php");
}


?>


<link rel="icon" href="../assets/images/others/favicon.ico">
<link rel="stylesheet" href="../assets/vendors/lightgallery/css/lightgallery-bundle.min.css">
<link rel="stylesheet" href="../assets/vendors/fontawesome/css/all.min.css">
<link rel="stylesheet" href="../assets/vendors/animate/animate.min.css">
<link rel="stylesheet" href="../assets/vendors/slick/slick.css">
<link rel="stylesheet" href="../assets/vendors/mapbox-gl/mapbox-gl.min.css">
<link rel="stylesheet" href="../npm/bootstrap-icons%401.9.1/font/bootstrap-icons.css">
<link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
      rel="stylesheet">
<link rel="stylesheet" href="../assets/css/theme.css">
<link rel="stylesheet" href="../npm/select2%404.0.13/dist/css/select2.min.css" />
<link rel="stylesheet" href="../npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
<main id="content" class="wrapper layout-page">
      <section class="pb-lg-20 pb-16">
            <div class="bg-body-secondary py-5">
                  <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-site py-0 d-flex justify-content-center">
                              <li class="breadcrumb-item active pl-0 d-flex align-items-center" aria-current="page">
                                    Admin Login
                              </li>
                        </ol>
                  </nav>
            </div>
            <div class="container">
                  <div class=" text-center pt-13 mb-12 mb-lg-15">
                        <div class="text-center">
                              <h2 class="fs-36px mb-11 mb-lg-14">Admin Account</h2>
                        </div>
                  </div>
                  <div class="row no-gutters">
                        <div class="col-lg-12 mx-auto">
                              <div class="row no-gutters">
                                    <div class="col-lg-8 mb-15 mb-lg-0 pe-xl-2 mx-auto ">
                                          <h3 class="fs-4 mb-10">Log In</h3>
                                          <h3 class="fs-4 mb-10 text-danger">
                                                <?php
                                                if ($error) {
                                                      echo "Please Check Your Email and Password";
                                                }
                                                ?>
                                          </h3>
                                          <form method="post">
                                                <div class="form-group mb-6">
                                                      <label for="user_login_email" class="visually-hidden">Email
                                                            address</label>
                                                      <input type="email" class="form-control" id="user_login_email"
                                                            placeholder="Email Address" name="email"
                                                            value="admin@gmail.com">
                                                </div>
                                                <div class="form-group mb-6">
                                                      <label for="user_login_password"
                                                            class="visually-hidden">Password</label>
                                                      <input type="password" class="form-control"
                                                            id="user_login_password" placeholder="Password"
                                                            name="password" value="123">
                                                </div>
                                                <button type="submit" class="btn btn-primary w-100 mb-7" name="submit"
                                                      submit>Submit</button>
                                          </form>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
      </section>
</main>
<script src="../ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="../npm/select2%404.0.13/dist/js/select2.full.min.js"></script>
<script src="../assets/vendors/chartjs/chart.min.js"></script>
<script src="../assets/vendors/bootstrap/js/bootstrap.bundle.js"></script>
<script src="../assets/vendors/clipboard/clipboard.min.js"></script>
<script src="../assets/vendors/vanilla-lazyload/lazyload.min.js"></script>
<script src="../assets/vendors/waypoints/jquery.waypoints.min.js"></script>
<script src="../assets/vendors/lightgallery/lightgallery.min.js"></script>
<script src="../assets/vendors/lightgallery/plugins/zoom/lg-zoom.min.js"></script>
<script src="../assets/vendors/lightgallery/plugins/thumbnail/lg-thumbnail.min.js"></script>
<script src="../assets/vendors/lightgallery/plugins/video/lg-video.min.js"></script>
<script src="../assets/vendors/lightgallery/plugins/vimeoThumbnail/lg-vimeo-thumbnail.min.js"></script>
<script src="../assets/vendors/isotope/isotope.pkgd.min.js"></script>
<script src="../assets/vendors/slick/slick.min.js"></script>
<script src="../assets/vendors/gsap/gsap.min.js"></script>
<script src="../assets/vendors/gsap/ScrollToPlugin.min.js"></script>
<script src="../assets/vendors/gsap/ScrollTrigger.min.js"></script>
<script src="../assets/vendors/mapbox-gl/mapbox-gl.js"></script>
<script src="../assets/js/dashboard.min.js"></script>